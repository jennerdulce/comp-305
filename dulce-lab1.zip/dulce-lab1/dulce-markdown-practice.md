# Markdown Practice

[Github MD Cheatsheet](https://github.com/adam-p/markdown-here/wiki/markdown-cheatsheet)

```python
y = 1
print("hi")
```

```js
let y = 1
console.log(hi)
```

`pseudocode here`

> to be or not to be, that is the question

<a href="https://www.youtube.com/watch?v=XTBhYqxIhE0&ab_channel=YUNGBAE"></a>

| Item       | Quantity        | Cost per unit | Total Cost
| ------------- |:-------------:| -----:| ----:|
| Apple      | > 9000 | $1.00 | $9000.00
| Raisins from my car floor    | 14      |   $0.00001| $0.00014
| My love for you | inf    |    tree fiddy | priceless
